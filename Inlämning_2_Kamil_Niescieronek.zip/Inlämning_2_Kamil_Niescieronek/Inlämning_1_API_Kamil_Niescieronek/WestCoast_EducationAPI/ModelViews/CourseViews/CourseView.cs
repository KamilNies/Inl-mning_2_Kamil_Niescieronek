﻿namespace WestCoast_EducationAPI.ModelViews
{
    public class CourseView
    {
        public string Name { get; set; }
        public decimal? Price { get; set; }
        public string Description { get; set; }
    }
}
