﻿namespace WestCoast_EducationAPI.ModelViews
{
    public class CourseViewToBeReturned : CourseViewForPosting
    {
        public int Id { get; set; }
    }
}
