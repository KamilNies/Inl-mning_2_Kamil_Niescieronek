﻿namespace WestCoast_EducationAPI.ModelViews
{
    public class SubjectViewToBeReturned : SubjectViewForPosting
    {
        public int Id { get; set; }
    }
}
