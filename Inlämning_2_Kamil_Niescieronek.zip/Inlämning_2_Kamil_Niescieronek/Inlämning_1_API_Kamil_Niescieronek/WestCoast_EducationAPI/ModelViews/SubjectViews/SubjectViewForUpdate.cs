﻿namespace WestCoast_EducationAPI.ModelViews
{
    public class SubjectViewForUpdate : SubjectViewForPosting
    {
    }
}
