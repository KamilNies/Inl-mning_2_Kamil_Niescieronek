﻿using System.Collections.Generic;

namespace WestCoast_EducationAPI.ModelViews
{
    public class TeacherViewForUpdate : TeacherViewForPosting
    {
    }
}
