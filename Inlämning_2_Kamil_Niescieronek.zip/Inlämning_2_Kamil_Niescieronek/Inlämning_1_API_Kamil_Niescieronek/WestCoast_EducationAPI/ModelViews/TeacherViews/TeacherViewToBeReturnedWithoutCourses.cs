﻿namespace WestCoast_EducationAPI.ModelViews
{
    public class TeacherViewToBeReturnedWithoutCourses : TeacherViewForPosting
    {
        public int Id { get; set; }
    }
}
