'use strict';
const elem = document.querySelectorAll('.main-carousel');

for (const carousel of elem) {
  const flkty = new Flickity( carousel, {
      // options
      cellAlign: 'left',
      contain: true,
      pageDots: false,
      groupCells: '80%',
      freeScroll: true
    }
  );

  flkty.on('dragStart', () => flkty.slider.childNodes.forEach(slide => slide.style.pointerEvents = 'none'));
  flkty.on('dragEnd', () => flkty.slider.childNodes.forEach(slide => slide.style.pointerEvents = 'all'));
}