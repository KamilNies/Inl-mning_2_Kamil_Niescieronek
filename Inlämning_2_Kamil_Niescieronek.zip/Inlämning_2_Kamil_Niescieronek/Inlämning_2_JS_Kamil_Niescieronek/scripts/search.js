'use strict';
const tab = document.querySelector('#tab-title');
const input = document.querySelector('input');
const search = document.querySelector('button');
const header = document.querySelector('.results');
const section = document.querySelector('section');

run();

async function run() {
    if (location.href.includes(`/admin/search.htm?search`)) {

        let search = '';
    
        const urlParams = new URLSearchParams(location.search);
    
        for (let [key, value] of urlParams) {

            if (key === 'search') search = value;
        }
    
        console.log(search);

        const courses = await findCourses(search);

        if (courses.size == 0) {

            tab.innerText = 'No results - Westcoast Education';
            header.innerHTML = `${search.trim()} 
            <i class="fas fa-chevron-right" 
            style="font-size: 1.25rem; color: var(--purple-color-highlight)"></i>`;
            return;

        } else {
            
            section.innerHTML = '';
            section.insertAdjacentHTML('afterbegin', generateHTML(courses));

            tab.innerText = 'Results - Westcoast Education';
            header.innerHTML = `${search.trim()} 
            <i class="fas fa-chevron-right" 
            style="font-size: 1.25rem; color: var(--purple-color-highlight)"></i>`;
        }  
    }
}

input.addEventListener('keydown', async (e) => {

    let query = input.value.trim();

    if (e.key === 'Enter') {
        if (query === '') return;
        if (location.href.endsWith(`/admin/search.htm?search=${query}`)) {

            const courses = findCourses(query);
            section.insertAdjacentHTML('afterbegin', generateHTML(courses));
        };
        location.href = `/admin/search.htm?search=${query}`;
    }
});

search.addEventListener('click', () => {

    let query = input.value.trim();
    if (query === '') return;
    if (location.href.endsWith(`/admin/search.htm?search=${query}`)) return;
        location.href = `/admin/search.htm?search=${query}`;
});

async function findCourses(search) {
    const results = new Set();

    const findCourseByName = `https://localhost:5001/api/course/courseName/${search}`;
    const findCourseBySubject = `https://localhost:5001/api/course/courseSubject/${search}`;

    const queryResponseByName = await fetch(findCourseByName);
    const queryResponseBySubject = await fetch(findCourseBySubject);

    if (!queryResponseByName.ok) throw new Error(queryResponseByName.statusText);
    if (!queryResponseBySubject.ok) throw new Error(queryResponseBySubject.statusText);

    const dataByName = await queryResponseByName.json();
    const dataBySubject = await queryResponseBySubject.json();

    for (const course of dataByName) {
        if (!courseExists(results, course)) {
            results.add(course);
        }
    }

    for (const course of dataBySubject) {
        if (!courseExists(results, course)) {
            results.add(course);
        }
    }

    return results;
}

function courseExists(results, course) {
    for (const object of results) {
        if (object.id === course.id) return true;
    }
    return false;
}

function generateHTML(courses) {
    let html = '';

    courses.forEach(course => {
        html += `<a class="video" href="/admin/video.htm?courseId=${course.id}">
                    <p class="animate__animated animate__fadeInUp">${course.name.substring(0, 18) + '...'}</p>
                    <i class="fas fa-play-circle"></i>
                    <img src="/assets/search/${course.id}.png" alt="${course.subject} video">
                </a>`;
    });

    return html;
}