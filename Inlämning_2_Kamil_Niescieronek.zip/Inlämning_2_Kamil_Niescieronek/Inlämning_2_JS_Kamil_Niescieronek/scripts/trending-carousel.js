'use strict';
var elem = document.querySelector('.main-carousel');
var flkty = new Flickity(elem, {
  // options
  cellAlign: 'left',
  contain: true,
  pageDots: false,
  groupCells: '80%',
  draggable: false,
  wrapAround: true
});

