'use strict';
const tab = document.querySelector('#tab-title');
const title = document.querySelector('#title');
const teacher = document.querySelector('.teacher-name');
const subject = document.querySelector('.subject');
const description = document.querySelector('.description');

async function  getCourse() {
    let courseId = 0;

    const urlParams = new URLSearchParams(location.search);

    for (let [key, value] of urlParams) {
        if (key === 'courseId') courseId = value;
    }

    const course = await loadCourseAsync(courseId);
    overwriteHtml(course);
}

async function loadCourseAsync(courseId) {
    if (courseId == 0) return {
        id: 0,
        name: "Title",
        price: 0,
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec justo dapibus, ultrices tortor sed, efficitur ante. Mauris porttitor erat ut suscipit suscipit. Suspendisse potenti. Suspendisse sed neque hendrerit nisl posuere porta sit amet vel lacus. Integer ante mi, facilisis quis ipsum at, imperdiet cursus ex. Vestibulum vulputate lacus in magna efficitur elementum. Pellentesque commodo mauris sed tellus congue accumsan. Nulla commodo ligula ut massa pulvinar ullamcorper. Suspendisse consequat efficitur est id varius. Nunc tempus vitae justo in sollicitudin. Quisque vehicula augue ac tortor ultricies, id lobortis turpis pellentesque.",
        teacherFirstName: "Teacher",
        teacherLastName: "",
        subject: "Subject"
    };

    const url = `https://localhost:5001/api/course/${courseId}`;
    const response = await fetch(url)

    if (!response.ok) throw new Error(response.statusText);

    return await response.json();
}

function overwriteHtml(course) {
    tab.innerText = `${course.name} - Westcoast Education`;
    title.innerText = `${course.name}`;
    teacher.innerHTML = `<i class="fas fa-user"></i> ${course.teacherFirstName} ${course.teacherLastName}`;
    subject.innerHTML = `<img src="/assets/subject/${course.subject === 'C#' ? 
    'C%23' : course.subject === 'Visual Basic' ? 'VisualBasic' : course.subject}.svg" alt="${course.subject} icon" ${course.subject === 'Java' ? 
    'style="background-color: var(--text-color); border-radius: 0.2rem; padding: 0 0.1rem"' : ''}
    ${course.subject === 'PHP' ? 'style="background-color: white; border-radius: 0.2rem; opacity: 30%;"' : 
    ''}>${course.subject}`;
    description.innerText = `${course.description}`;
}

getCourse();