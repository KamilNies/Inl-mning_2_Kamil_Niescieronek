'use strict';
const cells = document.querySelectorAll('.trending-cell');
const images = document.querySelectorAll('.trending-cell-container img');
const titles = document.querySelectorAll('.trending-bottom h2');
const authors = document.querySelectorAll('.trending-author');
const prices = document.querySelectorAll('.price');
const subjects = document.querySelectorAll('.subject');
const list = document.querySelector('.course-video-list-container');

async function loadCourses() {

    const url = 'https://localhost:5001/api/course';

    const response = await fetch(url);

    if (!response.ok) return;

    list.innerHTML = '';

    const data = await response.json();
    populateCells(data);
    list.insertAdjacentHTML('afterbegin', generateHtml(data));
}

function populateCells(courses) {
    for (let i = 0; i < cells.length; i++) {
        cells[i].setAttribute('href', `/admin/video.htm?courseId=${courses[i].id}`);
        images[i].setAttribute('src', `/assets/trending/${courses[i].id}.png`);
        images[i].setAttribute('alt', `${courses[i].subject} cover`);
        titles[i].innerText = courses[i].name;
        authors[i].innerText = `by ${courses[i].teacherFirstName} ${courses[i].teacherLastName}`;
        prices[i].innerHTML = `<i class="fas fa-coins"></i>${courses[i].price} kr`;
        subjects[i].innerHTML = `<img src="/assets/subject/${courses[i].subject === 'C#' ? 
        'C%23' : courses[i].subject === 'Visual Basic' ? 'VisualBasic' : courses[i].subject}.svg" alt="${courses[i].subject} icon" ${courses[i].subject === 'Java' ? 
        'style="background-color: var(--text-color); border-radius: 0.2rem; padding: 0 0.1rem"' : ''}
        ${courses[i].subject === 'PHP' ? 'style="background-color: white; border-radius: 0.2rem; opacity: 30%;"' : 
        ''}>${courses[i].subject}`;
    }
}

function generateHtml(courses) {
    let html = '';
    courses.forEach(course => {
        html += `<a href="/admin/video.htm?courseId=${course.id}" class="course-video-data-container">
                    <h2>${course.name}</h2>
                    <div class="list-information-layer">
                        <p class="list-name">by ${course.teacherFirstName} ${course.teacherLastName}</p>
                        <table>
                            <tr>
                                <th class="list-subject"><img src="/assets/subject/${course.subject === 'C#' ? 
                                'C%23' : course.subject === 'Visual Basic' ? 'VisualBasic' : course.subject}.svg" alt="${course.subject} icon" ${course.subject === 'Java' ? 
                                'style="background-color: var(--text-color); border-radius: 0.2rem; padding: 0 0.1rem"' : ''}
                                ${course.subject === 'PHP' ? 'style="background-color: white; border-radius: 0.2rem; opacity: 30%;"' : 
                                ''}>${course.subject}</th>
                                <th class="list-price"><i class="fas fa-coins"></i>${course.price} kr</th>
                            </tr>
                        </table>
                    </div>
                </a>`;
    });

    return html;
}

loadCourses();