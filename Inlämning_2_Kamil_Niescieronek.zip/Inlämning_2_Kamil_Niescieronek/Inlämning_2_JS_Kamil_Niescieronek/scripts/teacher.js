'use strict';
const table = document.querySelector('#table');

async function loadTeachers() {
    const url = 'https://localhost:5001/api/teacher';

    const response = await fetch(url);
    
    if (!response.ok) return;

    table.innerHTML = '';

    const data = await response.json();
    table.insertAdjacentHTML('afterbegin', constructTable(data));
}

function constructTable(teachers) {
    let html = `<thead class="thead-dark">
                    <tr>
                        <th>First name</th>
                        <th>Last name</th>
                        <th>Email</th>
                    </tr>
                </thead>`;
                
    teachers.forEach(teacher => {
        html += `<tr>
                    <td>${teacher.firstName}</td>
                    <td>${teacher.lastName}</td>
                    <td>${teacher.email}</td>
                </tr>`;
    });

    return html;
}

loadTeachers();