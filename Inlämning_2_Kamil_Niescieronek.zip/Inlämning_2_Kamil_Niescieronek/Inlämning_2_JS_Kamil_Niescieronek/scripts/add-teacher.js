'use strict';
const firstName = document.querySelector('#firstName');
const lastName = document.querySelector('#lastName');
const email = document.querySelector('#email');
const submit = document.querySelector('#submit');

submit.addEventListener('click', sendForm);

async function sendForm() {
    if (firstName.value.trim() === '') return;
    if (lastName.value.trim() === '') return;
    if (email.value.trim() === '') return;

    let data = {
        FirstName: firstName.value.trim(),
        LastName: lastName.value.trim(),
        email: email.value.trim()
    };

    const url = 'https://localhost:5001/api/teacher';

    const response = await fetch(url, {
        method: "POST",
        headers: {
            "Content-Type" : "application/json"
        },
        body: JSON.stringify(data)
    });

    if (response.ok) location.reload();
}