'use strict';
window.onload = function() {
  Particles.init({
    selector: '.background'
  });
};

var particles = Particles.init({
  selector: '.background',
  color: ['#DA0463', '#404B69', '#DBEDF3'],
  connectParticles: true,
  responsive: [
    {
      breakpoint: 752,
      options: {
        maxParticles: 50,
      }
    }
  ]
});

