﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using WestCoast_EducationMVC.Models;

namespace WestCoast_EducationMVC.Controllers
{
    public class CourseController : Controller
    {
        // GET: CourseController
        public async Task<IActionResult> Index()
        {
            var url = "https://localhost:5001/api/course";
            using var client = new HttpClient();
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound();
            }

            var content = await response.Content.ReadAsStringAsync();

            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            var courses = JsonSerializer.Deserialize<IList<CourseModelToBeReturned>>(content, options);

            return View(courses);
        }

        // GET: CourseController/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var url = $"https://localhost:5001/api/course/{id}";
            using var client = new HttpClient();
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound();
            }

            var content = await response.Content.ReadAsStringAsync();

            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            var course = JsonSerializer.Deserialize<CourseModelToBeReturned>(content, options);

            return View(course);
        }

        // GET: CourseController/Create
        public async Task<IActionResult> Create()
        {
            var subjectUrl = "https://localhost:5001/api/subject";
            var teacherUrl = "https://localhost:5001/api/teacher";

            using var client = new HttpClient();
            var subjectResponse = await client.GetAsync(subjectUrl);
            var teacherResponse = await client.GetAsync(teacherUrl);

            if (!subjectResponse.IsSuccessStatusCode || !teacherResponse.IsSuccessStatusCode)
            {
                return NotFound();
            }

            var subjectContent = await subjectResponse.Content.ReadAsStringAsync();
            var teacherContent = await teacherResponse.Content.ReadAsStringAsync();

            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            var subjects = JsonSerializer.Deserialize<IEnumerable<SubjectModelToBeReturned>>(subjectContent, options);
            var teachers = JsonSerializer.Deserialize<IEnumerable<TeacherModelToBeReturnedWithoutCourses>>(teacherContent, options);

            var teacherNames = new List<TeacherFullName>();

            foreach (var teacher in teachers)
            {
                teacherNames.Add(new TeacherFullName { Teacher = $"{teacher.FirstName} {teacher.LastName}" });
            }

            ViewBag.Teacher = new SelectList(teacherNames, "Teacher", "Teacher");
            ViewBag.Subject = new SelectList(subjects, "Name", "Name");

            return View();
        }

        // POST: CourseController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CourseModelPostForm postForm)
        {
            var url = "https://localhost:5001/api/course";

            if (!ModelState.IsValid)
            {
                return View();
            }

            //I'll skip automapper since this time
            var postCourse = new CourseModelForPosting
            {
                Name = postForm.Name,
                Price = postForm.Price,
                Description = postForm.Description,
                TeacherFirstName = postForm.Teacher.Split(' ')[0],
                TeacherLastName = postForm.Teacher.Split(' ')[1],
                Subject = postForm.Subject
            };

            using var client = new HttpClient();

            var content = new StringContent(JsonSerializer.Serialize(postCourse), Encoding.UTF8);

            content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            var response = await client.PostAsync(url, content);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound();
            }

            return RedirectToAction("Index");
        }

        // GET: CourseController/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var url = $"https://localhost:5001/api/course/{id}";
            using var client = new HttpClient();
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound();
            }

            var content = await response.Content.ReadAsStringAsync();

            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            var course = JsonSerializer.Deserialize<CourseModelToBeReturned>(content, options);

            ViewBag.Name = course.Name;
            //Removes the ',' and everything that comes after in the form.
            ViewBag.Price = course.Price.ToString().Substring(0, course.Price.ToString().IndexOf(","));
            ViewBag.Description = course.Description;

            return View();
        }

        // POST: CourseController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, CourseModelForUpdate updateCourse)
        {
            var url = $"https://localhost:5001/api/course/{id}";

            if (!ModelState.IsValid)
            {
                return View();
            }

            using var client = new HttpClient();

            var content = new StringContent(JsonSerializer.Serialize(updateCourse), Encoding.UTF8);

            content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            var response = await client.PutAsync(url, content);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound();
            }

            return RedirectToAction("Index");
        }

        // GET: CourseController/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var url = $"https://localhost:5001/api/course/{id}";
            using var client = new HttpClient();
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound();
            }

            var content = await response.Content.ReadAsStringAsync();

            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            var course = JsonSerializer.Deserialize<CourseModelToBeReturned>(content, options);

            return View(course);
        }

        // POST: CourseController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id, CourseModelToBeReturned deleteCourse)
        {
            var url = $"https://localhost:5001/api/course/{id}";
            using var client = new HttpClient();
            var response = await client.DeleteAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound();
            }

            return RedirectToAction("Index");
        }
    }
}
