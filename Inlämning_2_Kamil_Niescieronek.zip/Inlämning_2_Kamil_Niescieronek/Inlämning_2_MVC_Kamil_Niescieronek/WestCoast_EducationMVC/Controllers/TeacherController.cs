﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using WestCoast_EducationMVC.Models;

namespace WestCoast_EducationMVC.Controllers
{
    public class TeacherController : Controller
    {
        // GET: TeacherController
        public async Task<IActionResult> Index()
        {
            var url = "https://localhost:5001/api/teacher";
            using var client = new HttpClient();
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound();
            }

            var content = await response.Content.ReadAsStringAsync();

            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            var teachers = JsonSerializer.Deserialize<IList<TeacherModelToBeReturnedWithoutCourses>>(content, options);

            return View(teachers);
        }

        // GET: TeacherController/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var url = $"https://localhost:5001/api/teacher/{id}";
            using var client = new HttpClient();
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound();
            }

            var content = await response.Content.ReadAsStringAsync();

            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            var teacher = JsonSerializer.Deserialize<TeacherModelToBeReturnedWithoutCourses>(content, options);

            return View(teacher);
        }
        
        // GET: TeacherController/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: TeacherController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(TeacherModelForPosting postTeacher)
        {
            var url = "https://localhost:5001/api/teacher";

            if (!ModelState.IsValid)
            {
                return View();
            }

            using var client = new HttpClient();

            var content = new StringContent(JsonSerializer.Serialize(postTeacher), Encoding.UTF8);

            content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            var response = await client.PostAsync(url, content);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound();
            }

            return RedirectToAction("Index");
        }

        // GET: TeacherController/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var url = $"https://localhost:5001/api/teacher/{id}";
            using var client = new HttpClient();
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound();
            }

            var content = await response.Content.ReadAsStringAsync();

            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            var teacher = JsonSerializer.Deserialize<TeacherModelToBeReturnedWithoutCourses>(content, options);

            ViewBag.FirstName = teacher.FirstName;
            ViewBag.LastName = teacher.LastName;
            ViewBag.Email = teacher.Email;

            return View();
        }

        // POST: TeacherController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, TeacherModelForUpdate updateTeacher)
        {
            var url = $"https://localhost:5001/api/teacher/{id}";

            if (!ModelState.IsValid)
            {
                return View();
            }

            using var client = new HttpClient();

            var content = new StringContent(JsonSerializer.Serialize(updateTeacher), Encoding.UTF8);

            content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            var response = await client.PutAsync(url, content);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound();
            }

            return RedirectToAction("Index");
        }

        // GET: TeacherController/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var url = $"https://localhost:5001/api/teacher/{id}";
            using var client = new HttpClient();
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound();
            }

            var content = await response.Content.ReadAsStringAsync();

            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            var teacher = JsonSerializer.Deserialize<TeacherModelToBeReturnedWithoutCourses>(content, options);

            return View(teacher);
        }

        // POST: TeacherController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id, TeacherModelToBeReturnedWithoutCourses deleteTeacher)
        {
            var url = $"https://localhost:5001/api/teacher/{id}";
            using var client = new HttpClient();
            var response = await client.DeleteAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound();
            }

            return RedirectToAction("Index");
        }
    }
}
