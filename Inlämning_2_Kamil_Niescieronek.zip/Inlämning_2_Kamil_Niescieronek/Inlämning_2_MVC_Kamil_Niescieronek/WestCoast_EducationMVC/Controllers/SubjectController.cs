﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using WestCoast_EducationMVC.Models;

namespace WestCoast_EducationMVC.Controllers
{
    public class SubjectController : Controller
    {
        // GET: SubjectController
        public async Task<IActionResult> Index()
        {
            var url = "https://localhost:5001/api/subject";
            using var client = new HttpClient();
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound();
            }

            var content = await response.Content.ReadAsStringAsync();

            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            var subjects = JsonSerializer.Deserialize<IList<SubjectModelToBeReturned>>(content, options);

            return View(subjects);
        }

        // GET: SubjectController/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var url = $"https://localhost:5001/api/subject/{id}";
            using var client = new HttpClient();
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound();
            }

            var content = await response.Content.ReadAsStringAsync();

            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            var subject = JsonSerializer.Deserialize<SubjectModelToBeReturned>(content, options);

            return View(subject);
        }
        
        // GET: SubjectController/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: SubjectController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(SubjectModelForPosting postSubject)
        {
            var url = "https://localhost:5001/api/subject";

            if (!ModelState.IsValid)
            {
                return View();
            }

            using var client = new HttpClient();

            var content = new StringContent(JsonSerializer.Serialize(postSubject), Encoding.UTF8);

            content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            var response = await client.PostAsync(url, content);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound();
            }

            return RedirectToAction("Index");
        }

        // GET: SubjectController/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var url = $"https://localhost:5001/api/subject/{id}";
            using var client = new HttpClient();
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound();
            }

            var content = await response.Content.ReadAsStringAsync();

            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            var subject = JsonSerializer.Deserialize<SubjectModelToBeReturned>(content, options);

            ViewBag.Name = subject.Name;

            return View();
        }

        // POST: SubjectController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, SubjectModelForUpdate updateSubject)
        {
            var url = $"https://localhost:5001/api/subject/{id}";

            if (!ModelState.IsValid)
            {
                return View();
            }

            using var client = new HttpClient();

            var content = new StringContent(JsonSerializer.Serialize(updateSubject), Encoding.UTF8);

            content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            var response = await client.PutAsync(url, content);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound();
            }

            return RedirectToAction("Index");
        }

        // GET: SubjectController/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var url = $"https://localhost:5001/api/subject/{id}";
            using var client = new HttpClient();
            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound();
            }

            var content = await response.Content.ReadAsStringAsync();

            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            var subject = JsonSerializer.Deserialize<SubjectModelToBeReturned>(content, options);

            return View(subject);
        }

        // POST: SubjectController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id, SubjectModelToBeReturned deleteSubject)
        {
            var url = $"https://localhost:5001/api/subject/{id}";
            using var client = new HttpClient();
            var response = await client.DeleteAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound();
            }

            return RedirectToAction("Index");
        }
    }
}